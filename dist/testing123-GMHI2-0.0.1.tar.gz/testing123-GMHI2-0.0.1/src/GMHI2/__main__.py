from . import example

def main():
    example.run_GMHI2()

if __name__ == "__main__":
    main()
