def run_GMHI2():
    print("Running GMHI2!!")
